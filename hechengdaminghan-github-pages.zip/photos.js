(() => {
  const key = 'photo-merge-theme-v1';
  const defaults = Array.from({length: 11}, (_, i) => 'photos/' + i + '.jpg?v=6');
  const images = new Map();
  const load = src => new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });

  function crop(img, canvas) {
    const {width, height} = canvas;
    const size = Math.min(img.naturalWidth, img.naturalHeight);
    canvas.getContext('2d').drawImage(img, (img.naturalWidth-size)/2,
      (img.naturalHeight-size)/2, size, size, 0, 0, width, height);
  }

  window.photoTheme = {
    ready: Promise.all(defaults
      .map(async src => {
        try { images.set(src, await load(src)); } catch {}
      })),
    apply(frames) {
      for (let i = 0; i < Math.min(frames.length, defaults.length); i++) {
        const original = frames[i];
        const size = original.getOriginalSize();
        const width = Math.round(size.width);
        const height = Math.round(size.height);
        if (!width || !height) continue;
        const image = images.get(defaults[i]);
        if (!image) continue;
        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        ctx.beginPath();
        ctx.ellipse(width/2, height/2, width/2 - 1, height/2 - 1, 0, 0, 2*Math.PI);
        ctx.clip();
        crop(image, canvas);
        const texture = new cc.Texture2D();
        texture.initWithElement(canvas);
        texture.packable = false;
        frames[i] = new cc.SpriteFrame(texture);
      }
    }
  };

})();
