(() => {
  const get = id => document.getElementById('rank-' + id);
  const dialog = get('dialog');
  const form = get('form');
  const list = get('list');
  const status = get('status');
  const more = get('more');
  const submit = form.querySelector('button[type=submit]');
  const profileDialog = get('profile');
  const profileStatus = get('profile-status');
  const profileKey = 'photo-rank-profile-v1';
  const pendingKey = 'photo-rank-pending-v1';
  let page = 0;
  let generation = 0;
  let round = crypto.randomUUID();
  let finished = false;
  let sending = false;
  let noticeTimer;
  const read = (key, fallback) => {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; }
    catch { return fallback; }
  };
  const write = (key, value) => {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch {}
  };
  let profile = read(profileKey, null);
  let pending = read(pendingKey, []);

  function notify(text, clear = false) {
    const notice = get('notice');
    clearTimeout(noticeTimer);
    notice.textContent = text;
    if (clear) noticeTimer = setTimeout(() => { notice.textContent = ''; }, 3500);
  }

  window.photoRank = {
    startRound() {
      round = crypto.randomUUID();
      finished = false;
    },
    finish(score) {
      if (!profile || finished || !Number.isInteger(score) || score < 0) return;
      finished = true;
      pending.push({ round, score, ...profile });
      write(pendingKey, pending);
      sendPending();
    }
  };

  async function sendPending() {
    if (sending || !pending.length) return;
    sending = true;
    try {
      while (pending.length) {
        await request({
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(pending[0])
        });
        pending.shift();
        write(pendingKey, pending);
      }
      notify('成绩已上榜', true);
      if (dialog.open) load(true);
    } catch {
      notify('成绩待同步，打开排行榜可重试');
    } finally {
      sending = false;
    }
  }

  function appendEntry(entry) {
    const row = document.createElement('li');
    const rank = document.createElement('span');
    rank.textContent = list.children.length + 1;
    const avatar = document.createElement(entry.avatar ? 'img' : 'span');
    avatar.className = 'rank-avatar';
    if (entry.avatar) {
      avatar.src = entry.avatar;
      avatar.alt = '';
    } else {
      avatar.textContent = '🍉';
      avatar.setAttribute('aria-hidden', 'true');
    }
    const name = document.createElement('span');
    name.textContent = entry.name;
    const points = document.createElement('strong');
    points.textContent = entry.score;
    row.append(rank, avatar, name, points);
    list.append(row);
  }

  async function request(options, query = '') {
    const response = await fetch('https://photo-merge-archive.d412459.chatgpt.site/api/leaderboard' + query, options);
    const result = await response.json();
    if (!response.ok) throw new Error(result.error || '排行榜暂时无法访问。');
    return result;
  }

  async function load(reset) {
    const current = ++generation;
    if (reset) {
      list.replaceChildren();
      page = 0;
    }
    more.hidden = true;
    status.textContent = '正在加载排行榜…';
    try {
      const result = await request(undefined, '?page=' + page);
      if (current !== generation) return;
      result.entries.forEach(appendEntry);
      status.textContent = list.children.length ? '' : '还没有成绩，来留下第一条吧。';
      more.hidden = !result.more;
      page++;
    } catch {
      if (current !== generation) return;
      status.textContent = '排行榜加载失败，请重试。';
      more.hidden = false;
    }
  }

  async function makeAvatar(file) {
    if (!file) return null;
    const url = URL.createObjectURL(file);
    try {
      const image = new Image();
      image.src = url;
      await image.decode();
      const size = Math.min(image.naturalWidth, image.naturalHeight);
      const canvas = document.createElement('canvas');
      canvas.width = canvas.height = 96;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#faf9f6';
      ctx.fillRect(0, 0, 96, 96);
      ctx.drawImage(image, (image.naturalWidth-size)/2, (image.naturalHeight-size)/2, size, size, 0, 0, 96, 96);
      return canvas.toDataURL('image/jpeg', .78);
    } finally {
      URL.revokeObjectURL(url);
    }
  }

  get('open').onclick = () => {
    if (!profile) return;
    dialog.showModal();
    load(true);
    sendPending();
  };
  get('close').onclick = () => dialog.close();
  more.onclick = () => load(false);
  profileDialog.addEventListener('cancel', event => event.preventDefault());
  form.onsubmit = async event => {
    event.preventDefault();
    const name = form.elements.nickname.value.trim();
    if (!name || name.length > 20 || /[\x00-\x1f\x7f]/.test(name)) {
      profileStatus.textContent = '请输入 1–20 个字符的昵称。';
      return;
    }
    submit.disabled = true;
    try {
      const avatar = await makeAvatar(get('avatar').files[0]);
      profile = { name, avatar };
      write(profileKey, profile);
      profileDialog.close();
    } catch {
      profileStatus.textContent = '这张头像无法读取，可以换一张或跳过。';
    } finally {
      submit.disabled = false;
    }
  };
  if (!profile) profileDialog.showModal();
  window.addEventListener('online', sendPending);
  sendPending();
})();
